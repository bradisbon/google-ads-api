# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['google_ads_api']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp>=3.8.1,<4.0.0', 'pyyaml>=6.0,<7.0', 'requests>=2.27.1,<3.0.0']

setup_kwargs = {
    'name': 'google-ads-api',
    'version': '5.0.0',
    'description': 'API Client for Google Ads API',
    'long_description': None,
    'author': 'bradi',
    'author_email': 'bradisbon@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
