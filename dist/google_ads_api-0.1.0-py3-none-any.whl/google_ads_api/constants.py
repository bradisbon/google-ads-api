API_VERSION = 'v10'
CREDENTIALS_PATH = '~/.credentials/googleads.yaml'
MCC_ID = '5220257314'
